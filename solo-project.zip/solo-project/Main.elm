module Main exposing (..)

import Html.App as App
import Html exposing (..)
import Html.Attributes exposing (href, class, style)
import Material
import Material.Scheme
import Material.Button as Button
import Material.Options exposing (css)
import Material.Layout as Layout
import Material.Color as Color

-- MODEL

type alias Model =
    { count : Int
    , mdl :
        Material.Model
    , selectedTab : Int
    }
model : Model
model =
    { count = 0
    , mdl =
        Material.model
    , selectedTab = 0
    }

-- ACTION, UPDATE

type Msg
    = Increase
    | Reset
    | Mdl (Material.Msg Msg)
    | SelectTab Int

update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        Increase ->
            ( { model | count = model.count + 1 }
            , Cmd.none
            )

        Reset ->
            ( { model | count = 0 }
            , Cmd.none
            )

        -- When the `Mdl` messages come through, update appropriately.
        Mdl msg' ->
            Material.update msg' model

        SelectTab num ->
          { model | selectedTab = num } ! []
-- VIEW

type alias Mdl =
    Material.Model

view : Model -> Html Msg
view model =
  Material.Scheme.topWithScheme Color.Teal Color.LightGreen <|
    Layout.render Mdl
        model.mdl
        [ Layout.fixedHeader
        , Layout.selectedTab model.selectedTab
        , Layout.onSelectTab SelectTab
        ]
        { header = [ h1 [ style [ ( "padding", "2rem" ) ] ] [ text "Budgeting Tool" ] ]
        , drawer = []
        , tabs = ( [ text "Events", text "Challenges" ], [ Color.background (Color.color Color.Teal Color.S400) ] )
        , main = [ viewBody model ]
        }

viewBody : Model -> Html Msg
viewBody model =
  case model.selectedTab of
    0 ->
      viewCounter model

    1 ->
      text "something else"

    _ ->
      text "404"

viewCounter : Model -> Html Msg
viewCounter model =
    div
        [
        style [ ( "padding", "2rem" ) ] ]
        [ text ("Current count: " ++ toString model.count)
        , Button.render Mdl
            [ 0 ]
            model.mdl
            [ Button.onClick Increase
            , css "margin" "0 24px"
            ]
            [ text "Increase" ]
        , Button.render Mdl
            [ 1 ]
            model.mdl
            [ Button.onClick Reset ]
            [ text "Reset" ]
        ]

main : Program Never
main =
    App.program
        { init = ( model, Cmd.none )
        , view = view
        , subscriptions = always Sub.none
        , update = update
        }