use Mix.Config

# In this file, we keep production configuration that
# you likely want to automate and keep it away from
# your version control system.
#
# You should document the content of this
# file or create a script for recreating it, since it's
# kept out of version control and might be hard to recover
# or recreate for your teammates (or you later on).
config :solo_project, SoloProject.Endpoint,
  secret_key_base: "GvmUf1Ut9TcmcwqNRiCieMEp8mnFMD6c75udYf+moHW3pN6xlAd6db29dofMwj7y"

# Configure your database
config :solo_project, SoloProject.Repo,
  adapter: Ecto.Adapters.Postgres,
  username: "postgres",
  password: "postgres",
  database: "solo_project_prod",
  pool_size: 20
