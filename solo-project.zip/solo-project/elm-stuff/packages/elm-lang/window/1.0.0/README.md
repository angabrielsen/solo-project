# Window Size

Your application lives in a window. This library helps you figure out how big that window is and when it changes size.