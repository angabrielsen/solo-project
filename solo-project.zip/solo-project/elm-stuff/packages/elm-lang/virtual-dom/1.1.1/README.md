# Virtual DOM for Elm

A virtual DOM implementation that backs Elm's core libraries for [HTML](http://package.elm-lang.org/packages/elm-lang/html/latest/) and [SVG](http://package.elm-lang.org/packages/elm-lang/html/latest/). You should almost certainly use those higher-level libraries directly.
