6.0.0

New components: Footers, Spinners, Progress, Toggles, Tables & Tooltips.
Multiple bug-fixes and enhancements.

Credits

1. Alexander Foremny (@aforemny), core contributor, commit-rights. 

    In a *massive* and very sophisticated contribution for this release,
    Alexander contributed both numerous minor fixes and four entirely new
    components: Menus, Tables, Progress bar, Spinner.  

2. Ville Penttinen (@vipentti), new contributor

    In an impressive initial contribution, Ville contributed both
    demo work, multiple enhancements to Layout Textfield, and two new
    components, Footer & Tooltip. all produced in an impressively short
    span of time. 

3. @SauceWaffle, new contributor.

    Very useful customisation of Menu icon.

4. Petre Damoc (@pdamoc), new contributor.

    Bugfixes to subtle CSS interaction problems in Layout. 

5. Søren Debois (@debois), original author. 
    
    Remaining components, demo work, lots of bug fixes. I also 
    likely introduced any bugs you might find.

Thanks to all contributors, new as old, including from previous releases!
Elm-mdl is rapidly approaching a comprehensive and usable UI toolkit; this 
is because of you. For that, I am very grateful. 


